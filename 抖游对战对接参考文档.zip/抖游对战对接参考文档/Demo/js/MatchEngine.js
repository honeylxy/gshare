/*
* 本文件为匹配阶段的自定义操作对象
* */

function Engine(MatchEngine,gameconfig,userProfile) {
    this.config = gameconfig;
    this.engine = MatchEngine;
    this.userProfile = userProfile;
}
Engine.prototype = {
    //初始化
    init: function (engine,response, channel, platform) {
        return this.engine.init(response, channel, platform, this.config.gameId);
    },

    //绑定第三方账号
    bindOpenIDWithUserID : function(obj){
        var reqUrl = this.config.environment == 1?"http://alphavsuser.matchvs.com/wc6/thirdBind.do?":"https://vsuser.matchvs.com/wc6/thirdBind.do?";//测试地址
        var appKey = this.config.Appkey;
        var secretKey = this.config.Secret;
        var params = appKey+"&gameID="+this.config.gameId+"&openID="+JSON.parse(this.userProfile)["UserID"]+"&session=123reqafg9dfa0tja&thirdFlag=1&"+secretKey;
        var signstr = hex_md5(params);//md5加密
        var jsonParam = "userID=0&gameID="+this.config.gameId+"&openID="+JSON.parse(this.userProfile)["UserID"]+"&session=123reqafg9dfa0tja&thirdFlag=1&sign="+signstr;
        var request = new MatchvsHttp(obj);
        request.post(reqUrl,jsonParam);

    },

    //登陆
    login: function (userID, token) {
        this.engine.login(userID, token, this.config.gameId, this.config.gameVersion, this.config.Appkey, this.config.Secret, this.config.deviceID, this.config.gatewayID);
    },

    //加入指定房间
    joinRandomRoom : function (maxPlayer) {
        var resGroup = {0:0,"-1":"加入失败","-2":"未初始化","-3":"正在初始化","-4":"未登录","-5":"正在创建或者进入房间","-6":"已经在房间中","-20":"房间人数必须在1~20之间","-21":"用户信息过长"};
        var res = this.engine.joinRandomRoom(maxPlayer, this.userProfile);
        return resGroup[res];
    },

    //创建房间
    createRoom : function (createRoomInfo) {
        var resGroup = {0:0,"-1":"创建房间失败","-2":"未初始化","-3":"正在初始化","-4":"未登录","-7":"正在创建或者进入房间","-8":"已在房间","-21":"用户信息过长"};
        var res = this.engine.createRoom(createRoomInfo, this.userProfile);
        return resGroup[res];
    },

    //离开房间
    leaveRoom : function (cpProto) {
        var resGroup = {0:0,"-1":"创建房间失败","-2":"未初始化","-3":"正在初始化","-4":"未登录","-7":"正在创建或者进入房间","-6":"不在房间","-21":"用户信息过长"};
        var res = this.engine.leaveRoom(cpProto);
        return resGroup[res];
    },

    //带属性加入房间
    joinRoomWithProperties : function (matchInfo) {
        var resGroup = {0:0,"-1":"正在加入房间","-4":"未登录，请先登陆","-20":"房间人数在1到20之间"};
        var res = this.engine.joinRoomWithProperties(matchInfo, this.userProfile);
        return resGroup[res];
    },

    //加入指定房间
    joinRoom : function (roomID) {
        var resGroup = {0:0,"-1":"加入失败","-2":"未初始化","-3":"正在初始化","-4":"未登录","-7":"正在创建或者进入房间","-8":"已经在房间中","-21":"用户信息过长"};
        var res = this.engine.joinRoom(roomID, this.userProfile);
        return resGroup[res];
    },

    //退出本游戏
    logout : function (cpProto) {
        var resGroup = {0:0,"-1":"退出游戏失败","-4":"未登录"};
        var res = this.engine.logout(cpProto);
        return resGroup[res];
    },
    
    //反初始化
    uninit : function () {
        var res = this.engine.uninit();
        return res;
    },
    
    //光比房间
    joinOver : function (cpProto) {
        var resGroup = {0:0,"-1":"关闭房间失败","-2":"未初始化","-3":"正在初始化","-4":"未登录","-7":"正在创建或者进入房间","-8":"已在房间","-21":"用户信息过长"};
        var res = this.engine.joinOver(cpProto);
        return resGroup[res];
    },
    
    //断网重连
    reconnect : function () {
        var resGroup = {0:0,"-1":"其他错误","-2":"未初始化","-9":"正在重连"};
        var res = this.engine.reconnect();
        return resGroup[res];
    }
    

}

var MatchEngine ={};//MatchVs官方的引擎对象
var gEngine = {};//自定义的用于在匹配阶段使用对象
var gResponse = {};//对原始MatchVsResponse的封装，同时用于匹配阶段的返回值调用
var pRes = {};
//初始化

function appInit(gameconfig,userProfile) {
    var gameconfig = JSON.parse(gameconfig);
    MatchEngine = new MatchvsEngine();
    gEngine = new Engine(MatchEngine,gameconfig,userProfile);
    gResponse = new GameResponse();
    pRes = new Presonse();
    MatchEngine.match(gEngine,gResponse,pRes,"MatchVS",gameconfig["environment"] ==1?"alpha":"release");
}



//随机加入游戏
function joinRandomRoom(maxPlayer){
    var res = gEngine.joinRandomRoom(maxPlayer);
    return res;
}

// 创建房间
function createRoom(createRoomInfo) {
    var createRoomInfo = JSON.parse(createRoomInfo);
    var res = gEngine.createRoom(createRoomInfo);
    return res;
}

//离开房间
function leaveRoom(cpProto) {
    var res = gEngine.leaveRoom(cpProto);
    return res;
}

//带属性随机加入房间
function joinRoomWithProperties(matchInfo) {
    var matchInfos = JSON.parse(matchInfo);
    var res = gEngine.joinRoomWithProperties(matchInfos);
    return res;
}

//加入指定房间
function joinRoom(roomID) {
    var res = gEngine.joinRoom(roomID);
    return res;
}

//退出游戏
function  logout(cpProto) {
    var res = gEngine.logout(cpProto);
    return res;
}

//关闭房间
function joinOver(cpProto) {
    var res = gEngine.joinOver(cpProto);
    return res;
}

//断网重连
function reconnect() {
    var res = gEngine.reconnect();
    return res;
}