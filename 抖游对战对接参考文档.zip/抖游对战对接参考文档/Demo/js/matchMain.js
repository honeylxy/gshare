/*
    * engine : 自定义的匹配操作对象 ------对原始MatchVS对象的封装
    * gResponse : MatchVS的response-----对原始MatchvsResponse对象的封装
    * response : 游戏方调用时传入的response----游戏方调用时自定义的response对象。同时禁止在匹配阶段自定义response起作用
    * channel :渠道，固定值 "Matchvs" ----初始化时使用
    * platform :平台，测试or正式环境  测试用：alpha ,正式用release -----初始化时使用
    * */
MatchvsEngine.prototype.match = function (engine, gResponse, response, channel, platform) {
    gResponse.responseInit(engine, response);
    gResponse.notifyClient = false;
    gResponse.fromMatch = true;
    engine.init(this, gResponse, channel, platform);
};
function GameResponse() {
    this.notifyClient = true;//是否调用游戏的response
    this.fromMatch = false;
    this.obj = {};//游戏引擎
    this.response = {};//游戏的响应

    this.responseInit = function (obj, response) {
        this.obj = obj;
        this.response = response;
    };
    this.initResponse = function (status) {
        if(this.fromMatch){
            if (status == 200) {
                this.obj.bindOpenIDWithUserID(this);
            }
            return;
        }
        this.notifyClient && this.response.initResponse && this.response.initResponse(status);
    };
    this.onMsg = function(dataView){
        var dataView = JSON.parse(dataView);
        if(dataView["status"] == 0){
            console.log("第三方数据绑定成功");
            this.obj.login(dataView["data"]["userid"], dataView["data"]["token"]);
        }
    };
    this.loginResponse = function (loginRsp) {
        if(this.fromMatch){
            console.log("登陆成功");
            var res = JSON.stringify(loginRsp);
            CallAndroid.initRes(res);
            return;
        }
        this.notifyClient && this.response.loginResponse && this.response.loginResponse(loginRsp);
    };
    this.joinRoomResponse = function (status, roomUserInfoList, roomInfo) {
        if(this.fromMatch){
            var res = {
                status : status,
                roomUserInfoList : roomUserInfoList,
                roomInfo : roomInfo
            }
            res = JSON.stringify(res);
            console.error(res);
            CallAndroid.joinRoomRes(res);
            return;
        }
        this.notifyClient && this.response.joinRoomResponse && this.response.joinRoomResponse(status, roomUserInfoList, roomInfo);

    };
    this.createRoomResponse = function (CreateRoomRsp) {
        if(this.fromMatch){
            var res = JSON.stringify(CreateRoomRsp);
            console.error(res);
            CallAndroid.createRoomRes(res);
            return;
        }
        this.notifyClient && this.response.createRoomResponse && this.response.createRoomResponse(CreateRoomRsp);
    };
    this.leaveRoomResponse = function (leaveRoomRsp) {
        if(this.fromMatch){
            var res = JSON.stringify(leaveRoomRsp);
            console.error(res);
            CallAndroid.leaveRoomRes(res);
            return;
        }
        this.notifyClient && this.response.leaveRoomResponse && this.response.leaveRoomResponse(leaveRoomRsp);
    };
    this.joinRoomNotify = function (roomUserInfo) {
        if(this.fromMatch){
            var res = JSON.stringify(roomUserInfo);
            console.error(res);
            CallAndroid.joinRoomNotifyRes(res);
            return;
        }
        this.notifyClient && this.response.joinRoomNotify && this.response.joinRoomNotify(roomUserInfo);
    };
    this.leaveRoomNotify = function (leaveRoomInfo) {
        if(this.fromMatch){
            var res = JSON.stringify(leaveRoomInfo);
            console.error(res);
            CallAndroid.leaveRoomNotifyRes(res);
            return;
        }
        this.notifyClient && this.response.leaveRoomNotify && this.response.leaveRoomNotify(leaveRoomInfo);
    };
    this.logoutResponse = function (status) {
        if(this.fromMatch){
            var uninitRes = -1;
            var res = {};
            if(status == 200){
                uninitRes = this.obj.uninit();
            }
            res = {
                status : status,
                uninitRes : uninitRes
            }
            res = JSON.stringify(res);
            console.error(res);
            CallAndroid.logoutRes(res);
            return;
        }
        this.notifyClient && this.response.logoutResponse && this.response.logoutResponse(status);
    };
    this.joinOverResponse = function (joinOverRsp) {
        if(this.fromMatch){
            if(joinOverRsp.status == 200){
                this.notifyClient = true;
            }
            var res = JSON.stringify(joinOverRsp);
            console.error(res);
            CallAndroid.joinOverRes(res);
            return;
        }
        this.notifyClient && this.response.joinOverResponse && this.response.joinOverResponse(joinOverRsp);
    };
    this.joinOverNotify = function (notifyInfo) {
        if(this.fromMatch){
            var res = JSON.stringify(notifyInfo);
            console.error(res);
            CallAndroid.joinOverNotifyRes(res);
            return;
        }
        this.notifyClient && this.response.joinOverNotify && this.response.joinOverNotify(notifyInfo);
    };
    this.networkStateNotify = function (notify) {
        if(this.fromMatch){
            var res = JSON.stringify(notify);
            console.error(res);
            CallAndroid.networkStateNotifyRes(res);
            return;
        }
        this.notifyClient && this.response.networkStateNotify && this.response.networkStateNotify(notify);
    };
    this.reconnectResponse = function (status, roomUserInfoList, roomInfo) {
        if(this.fromMatch){
            var res = {
                status : status,
                roomUserInfoList : roomUserInfoList,
                roomInfo : roomInfo
            };
            res = JSON.stringify(res);
            CallAndroid.reconnectRes(res);
        }
        this.notifyClient && this.response.reconnectResponse && this.response.reconnectResponse(status, roomUserInfoList, roomInfo);
    };

    this.getRoomListResponse = function (status, roomInfos) {


        this.notifyClient && this.response.getRoomListResponse && this.response.getRoomListResponse(status, roomInfos);
    };


    this.kickPlayerResponse = function (rsp) {


        this.notifyClient && this.response.kickPlayerResponse && this.response.kickPlayerResponse(rsp);
    };

    this.kickPlayerNotify = function (notify) {


        this.notifyClient && this.response.kickPlayerNotify && this.response.kickPlayerNotify(notify);
    };

    this.sendEventResponse = function (rsp) {


        this.notifyClient && this.response.sendEventResponse && this.response.sendEventResponse(rsp);

    };

    this.sendEventNotify = function (tRsp) {


        this.notifyClient && this.response.sendEventNotify && this.response.sendEventNotify(tRsp);
    };

    this.gameServerNotify = function (tRsp) {


        this.notifyClient && this.response.gameServerNotify && this.response.gameServerNotify(tRsp);
    };

    this.errorResponse = function (errCode, errMsg) {


        this.notifyClient && this.response.errorResponse && this.response.errorResponse(errCode, errMsg);
    };


    this.subscribeEventGroupResponse = function (status, groups) {


        this.notifyClient && this.response.subscribeEventGroupResponse && this.response.subscribeEventGroupResponse(status, groups);
    };


    this.sendEventGroupResponse = function (status, dstNum) {


        this.notifyClient && this.response.sendEventGroupResponse && this.response.sendEventGroupResponse(status, dstNum);
    };

    this.sendEventGroupNotify = function (srcUid, groups, cpProto) {


        this.notifyClient && this.response.sendEventGroupNotify && this.response.sendEventGroupNotify(srcUid, groups, cpProto);
    };

    this.setFrameSyncResponse = function (rsp) {


        this.notifyClient && this.response.setFrameSyncResponse && this.response.setFrameSyncResponse(rsp);
    };

    this.sendFrameEventResponse = function (rsp) {
        this.notifyClient && this.response.sendFrameEventResponse && this.response.sendFrameEventResponse(rsp);
    };

    this.frameUpdate = function (data) {


        this.notifyClient && this.response.frameUpdate && this.response.frameUpdate(data);
    };

    this.hotelHeartBeatRsp = function (data) {


        this.notifyClient && this.response.hotelHeartBeatRsp && this.response.hotelHeartBeatRsp(data);
    };


    this.gatewaySpeedResponse = function (rsp) {


        this.notifyClient && this.response.gatewaySpeedResponse && this.response.gatewaySpeedResponse(rsp);
    };


    this.heartBeatResponse = function (rsp) {


        this.notifyClient && this.response.heartBeatResponse && this.response.heartBeatResponse(rsp);
    };


    this.roomCheckInNotify = function (rsp) {


        this.notifyClient && this.response.roomCheckInNotify && this.response.roomCheckInNotify(rsp);
    };


    this.disConnectResponse = function (rep) {


        this.notifyClient && this.response.disConnectResponse && this.response.disConnectResponse(rsp);
    };


    this.getRoomDetailResponse = function (rsp) {


        this.notifyClient && this.response.getRoomDetailResponse && this.response.getRoomDetailResponse(rsp);
    };


    this.getRoomListExResponse = function (rsp) {


        this.notifyClient && this.response.getRoomListExResponse && this.response.getRoomListExResponse(rsp);
    };


    this.setRoomPropertyResponse = function (rsp) {


        this.notifyClient && this.response.setRoomPropertyResponse && this.response.setRoomPropertyResponse(rsp);
    };


    this.setRoomPropertyNotify = function (notify) {


        this.notifyClient && this.response.setRoomPropertyNotify && this.response.setRoomPropertyNotify(notify);
    };

    this.joinOpenNotify = function (rsp) {

        this.notifyClient && this.response.joinOpenNotify && this.response.joinOpenNotify(rsp);
    };
    this.joinOpenResponse = function (notify) {


        this.notifyClient && this.response.joinOpenResponse && this.response.joinOpenResponse(notify);
    };
}